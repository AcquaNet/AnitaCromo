<?php
$conexion_base = mysqli_connect('localhost','root', '', 'materiales2');
?>